To store cache file
